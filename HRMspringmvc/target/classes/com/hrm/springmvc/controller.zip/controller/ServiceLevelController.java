package com.hrm.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.hrm.springmvc.entity.bean.EmployeeBean;
import com.hrm.springmvc.entity.service.DaoService;

@Controller
public class ServiceLevelController {
	
	@Autowired
	DaoService service;
	
	public ModelAndView readEmployeeRegistration(@ModelAttribute("employeeObj")EmployeeBean employeebean) {
		int result=0;
		ModelAndView modelAndViewRef=new ModelAndView();
		result=service.insertEmployeeData(employeebean);
		if(result>0) {
			modelAndViewRef.setViewName("userupdate");
		}else{
			modelAndViewRef.setViewName("EmployeeRegistration");
			
		}
		
		
		
		return modelAndViewRef;
		
	}

}
