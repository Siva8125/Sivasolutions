package com.hrm.springmvc.entity.service;

import com.hrm.springmvc.entity.bean.EmployeeBean;

public interface DaoService {

	public int insertEmployeeData(EmployeeBean employeebean);

}
