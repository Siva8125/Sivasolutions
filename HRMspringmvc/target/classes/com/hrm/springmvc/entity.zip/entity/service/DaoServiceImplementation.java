package com.hrm.springmvc.entity.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.hrm.springmvc.entity.bean.EmployeeBean;
import com.hrm.springmvc.entity.dao.Dao;

public class DaoServiceImplementation implements DaoService{
	@Autowired
	Dao dao;

	public int insertEmployeeData(EmployeeBean employeebean) {
		return dao.insertEmployeeData(employeebean);
	}

}
