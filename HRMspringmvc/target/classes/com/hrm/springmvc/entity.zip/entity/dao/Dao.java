package com.hrm.springmvc.entity.dao;

import com.hrm.springmvc.entity.bean.EmployeeBean;

public interface Dao {

	public int insertEmployeeData(EmployeeBean employeebean);
	

}
