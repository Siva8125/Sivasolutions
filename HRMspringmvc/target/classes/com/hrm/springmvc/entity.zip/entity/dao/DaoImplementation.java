package com.hrm.springmvc.entity.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.hrm.springmvc.entity.bean.EmployeeBean;

public class DaoImplementation implements Dao {
	@Autowired
	SessionFactory sessionfactory;

	public int insertEmployeeData(EmployeeBean employeebean) {
		int result=0;
		Session session=sessionfactory.openSession();
		Object obj=session.save(employeebean);
		Transaction trans=session.beginTransaction();
		trans.commit();
		if(obj!=null) {
			Integer itr=(Integer)obj;
			result=itr.intValue();
		}

		return result;
	}

}
